package quiz;

import java.util.Scanner;

public class Question{
	public static void main(String[] args)
	{
		//declare variables to 
		//keep track of the number of answers for each letter
		int A=0, B=0, C=0, D=0;
		char answer='a';
		Scanner in = new Scanner(System.in);
		
		// 6 questions, 4 answers each, therefore a 6x5 2D array
		int n = 6, p=5;
		String[][] question = new String[n][p];
		
		//the questions and answers
		question[0][0] = "reality";
		question[0][1] = "The material universe is all there is";
		question[0][2] = "Everything is God";
		question[0][3] = "We create our own reality";
		question[0][4] = "The universe is the creation of an intelligent creator";
		
		question[1][0] = "the human condition";
		question[1][1] = "We are all the products of matter, time and chance";
		question[1][2] = "We are all one with God";
		question[1][3] = "Emotions, feelings, intuition, and reflection are what define us";
		question[1][4] = "We are created by an intelligent creator";
		
		question[2][0] = "what happens to a person at death";
		question[2][1] = "Oblivion";
		question[2][2] = "They are reborn";
		question[2][3] = "Whatever they want to happen";
		question[2][4] = "They exist beyond death, either in relationship with the creator or not";
		
		question[3][0] = "why it is possible to know things";
		question[3][1] = "Knowledge is the result of physical processes in our brains";
		question[3][2] = "Knowledge comes from looking within";
		question[3][3] = "We can't really know anything";
		question[3][4] = "We are given intelligence and resources"; 
		
		question[4][0] = "morality";
		question[4][1] = "We decide for ourselves what is right and wrong";
		question[4][2] = "Sin is merely ignorance of the true nature of reality";
		question[4][3] = "All moral values are relative";
		question[4][4] = "We are given a moral nature which has become distorted due to free will";
		
		question[5][0] = "human history";
		question[5][1] = "It has no ultimate purpose";
		question[5][2] = "It has little meaning";
		question[5][3] = "It cannot be known";
		question[5][4] = "It has a purpose";
		
		// Display the questions and gather answers
		for(int i=0;i<n;i++)
		{
			System.out.println("Please type in the capital letter next to the phrase which most closely represents your view on " + question[i][0] + ".");
			
			for( int j=1;j<p;j++)
			{
				System.out.print((char)(j+64) +") ");
				System.out.println(question[i][j] +".");
			}
			answer = in.nextLine().charAt(0);
			
			// increment the scores
			switch(answer)
			{
				case('A'):
					A++;
					break;
				case('B'):
					B++;
					break;
				case('C'):
					C++;
					break;
				case('D'):
					D++;
					break;
			}
			
		}
		
		//display the final results
		System.out.println("Here are your results");
		System.out.println("A: " + A);
		System.out.println("B: " + B);
		System.out.println("C: " + C);
		System.out.println("D: " + D);
		in.close();
	}
}
